# **Minecraft Dungeons Cursor Theme**
## After searching for a good cursor resembling that of the one from the game Minecraft Dungeons, I have found none that do it properly. So, I have taken the liberty to datamine and compile one myself.
![Promo Image](https://cdn.bret06.net/img/cursor-promo.png)

# **How To Download**
## **1.** Right-click on the "MCD-Cursor-Theme.zip" and press "Extract All..."
## **2.** Choose where you wanna extract it, and open the folder
## **3.** Right-click on "!MCD Cursor Theme Installer.inf" and Click "Install"
## **4.** Press "Windows" and search "Mouse Settings"
## **5.** Click "Additional mouse settings"
## **6.** Inside of the new window that appeared select "Pointers"
## **7.** Click the dropdown, and select "Minecraft Dungeons Cursor Theme" (THERE WILL BE FOUR ERRORS JUST CLICK THROUGH THEM) and press apply.